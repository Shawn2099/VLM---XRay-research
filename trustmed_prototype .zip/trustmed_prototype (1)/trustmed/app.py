"""
TrustMed - Prototype (Review 1 simulation, ~20% of the project)

Implemented for real : upload + validation, preprocessing (resize / CLAHE / normalise),
                       result display, threshold-based flagging, "AI-assisted" labelling.
Simulated (stubs)    : report generation (canned reports) and the verification /
                       confidence-scoring module. Swap in the real code at the
                       functions marked  >>> REPLACE LATER <<<
"""
import base64, hashlib, random, time
import cv2
import numpy as np

# Real image-based engine: TorchXRayVision DenseNet (trained on 8 public chest X-ray datasets).
# If it is not installed, the app falls back to the old simulation so the demo never breaks.
try:
    import torch, torchvision, torchxrayvision as xrv
    ENGINE = "model"
except Exception:
    ENGINE = "simulation"
POS_THRESH = 0.5      # probability above which a finding is reported as present
N_VIEWS = 8           # augmented views used for uncertainty / consistency
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB (FR-2.2)
ALLOWED = {"jpg", "jpeg", "png"}                     # FR-2.1
DEFAULT_THRESHOLD = 0.75                             # FR-5.2 (configurable in UI)
MODEL_NAME, MODEL_VERSION = "generate-cxr (SIMULATED)", "stub-0.1"   # FR-3.2


# ---------------------------------------------------------------- preprocessing
def to_data_url(img):
    ok, buf = cv2.imencode(".png", img)
    return "data:image/png;base64," + base64.b64encode(buf).decode()


def preprocess(gray):
    """FR-2.3: resize -> CLAHE enhance -> normalise. Returns processed image + quality metrics."""
    resized = cv2.resize(gray, (512, 512), interpolation=cv2.INTER_AREA)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(resized)
    normalised = cv2.normalize(enhanced, None, 0, 255, cv2.NORM_MINMAX)
    sharp = float(cv2.Laplacian(resized, cv2.CV_64F).var())
    contrast = float(resized.std())
    # crude 0-1 image-quality estimate (used by the simulated scorer)
    quality = float(np.clip(0.5 * min(sharp / 300, 1) + 0.5 * min(contrast / 60, 1), 0, 1))
    return normalised, {"sharpness": round(sharp, 1), "contrast": round(contrast, 1),
                        "quality": round(quality, 2)}


# ---------------------------------------------------------------- report generation
REPORTS = {
    "normal": [
        "The cardiac silhouette is within normal limits.",
        "The lungs are clear without focal consolidation.",
        "No pleural effusion or pneumothorax is seen.",
        "The visualised osseous structures are unremarkable.",
    ],
    "pneumonia": [
        "The cardiac silhouette is within normal limits.",
        "There is patchy airspace opacity in the right lower lobe, suggestive of consolidation.",
        "A small right pleural effusion cannot be excluded.",
        "No pneumothorax is identified.",
    ],
    "covid": [
        "Bilateral peripheral ground-glass opacities are present.",
        "The cardiac silhouette is normal in size.",
        "No large pleural effusion is seen.",
        "Findings are non-specific and may represent an infectious or inflammatory process.",
    ],
    "cardiomegaly": [
        "The cardiac silhouette is enlarged, with a cardiothoracic ratio above 0.5.",
        "The lungs are clear without focal consolidation.",
        "Mild pulmonary vascular congestion is noted.",
        "No pleural effusion or pneumothorax is seen.",
    ],
    "pneumothorax": [
        "A visceral pleural line is seen in the right hemithorax with absent lung markings peripherally.",
        "Findings are consistent with a right-sided pneumothorax.",
        "The cardiac silhouette is within normal limits.",
        "No mediastinal shift is identified.",
    ],
    "tb": [
        "There is upper-zone fibro-nodular opacity with possible cavitation on the right.",
        "The cardiac silhouette is within normal limits.",
        "No pneumothorax is identified.",
        "Clinical correlation with sputum studies is recommended.",
    ],
}
# sentences a weak model might invent - used to demo hallucination detection (FR-4.3)
HALLUCINATIONS = [
    "A left-sided pacemaker lead is noted in situ.",
    "There is a healed fracture of the left third rib.",
    "A 2 cm nodule is present in the left upper zone.",
]


def pick_label(filename, rng, case="auto"):
    if case in REPORTS:
        return case
    name = filename.lower()
    for key in ("pneumonia", "covid", "tb", "tuberculosis", "normal", "cardiomegaly", "pneumothorax"):
        if key in name:
            return "tb" if key == "tuberculosis" else key
    return rng.choice(list(REPORTS))


def generate_report(filename, rng, case="auto"):
    """>>> REPLACE LATER <<<  call the real pre-trained model (generate-cxr) here."""
    label = pick_label(filename, rng, case)
    sentences = list(REPORTS[label])
    if rng.random() < 0.4:  # sometimes inject an unsupported finding
        sentences.insert(rng.randrange(1, len(sentences)), rng.choice(HALLUCINATIONS))
    return label, sentences



# ---------------------------------------------------------------- REAL engine
_model = None
def get_model():
    global _model
    if _model is None:  # first call downloads the weights (~30 MB, needs internet once)
        _model = xrv.models.DenseNet(weights="densenet121-res224-all").eval()
    return _model


def _prep(gray_u8):
    img = xrv.datasets.normalize(gray_u8, 255)[None, ...]
    tf = torchvision.transforms.Compose([xrv.datasets.XRayCenterCrop(), xrv.datasets.XRayResizer(224)])
    return tf(img).astype("float32")


def predict_findings(gray, seed=0):
    """Run the CNN on the image plus N_VIEWS-1 slightly perturbed copies (rotation, scale,
    brightness). Mean = prediction; spread across views = uncertainty (test-time augmentation)."""
    model = get_model()
    rng = np.random.default_rng(seed)
    h, w = gray.shape
    views = [gray]
    for _ in range(N_VIEWS - 1):
        M = cv2.getRotationMatrix2D((w / 2, h / 2), rng.uniform(-5, 5), rng.uniform(0.95, 1.05))
        v = cv2.warpAffine(gray, M, (w, h), borderMode=cv2.BORDER_REFLECT)
        v = np.clip(v.astype(np.float32) * rng.uniform(0.9, 1.1) + rng.uniform(-10, 10), 0, 255)
        views.append(v.astype(np.uint8))
    batch = torch.from_numpy(np.stack([_prep(v) for v in views]))
    with torch.no_grad():
        out = np.nan_to_num(model(batch).numpy())          # N_VIEWS x 18
    names = list(model.pathologies)
    findings = []
    for i, n in enumerate(names):
        col = out[:, i]
        findings.append({"name": n.replace("_", " "), "key": n, "prob": float(col.mean()),
                         "std": float(col.std()), "views": col})
    return findings


POS = {
    "Atelectasis": "There is evidence of atelectasis.",
    "Consolidation": "Airspace consolidation is present.",
    "Infiltration": "Pulmonary infiltrates are seen.",
    "Pneumothorax": "A pneumothorax is present.",
    "Edema": "Findings are suggestive of pulmonary edema.",
    "Emphysema": "Hyperinflation consistent with emphysema is noted.",
    "Fibrosis": "Fibrotic changes are present.",
    "Effusion": "A pleural effusion is present.",
    "Pneumonia": "Findings are suggestive of pneumonia.",
    "Pleural_Thickening": "Pleural thickening is noted.",
    "Cardiomegaly": "The cardiac silhouette is enlarged, consistent with cardiomegaly.",
    "Nodule": "A pulmonary nodule is seen.",
    "Mass": "A pulmonary mass is seen.",
    "Hernia": "A hiatal hernia is suspected.",
    "Lung Lesion": "A focal lung lesion is seen.",
    "Fracture": "A possible fracture is seen.",
    "Lung Opacity": "Lung opacity is present.",
    "Enlarged Cardiomediastinum": "The cardiomediastinal contour is enlarged.",
}
NEG = {
    "Pneumothorax": "No pneumothorax is seen.",
    "Effusion": "No pleural effusion is seen.",
    "Cardiomegaly": "The cardiac silhouette is within normal limits.",
    "Consolidation": "No focal consolidation is seen.",
}


def report_from_findings(findings):
    """Generate report sentences + per-sentence confidence + consistency check from CNN output."""
    sents = []
    pos = sorted([f for f in findings if f["prob"] >= POS_THRESH], key=lambda f: -f["prob"])[:5]
    items = [(f, True) for f in pos]
    if not pos:
        items.append((None, None))
    for f in findings:
        if f["key"] in NEG and f["prob"] < POS_THRESH:
            items.append((f, False))
    for f, present in items:
        if f is None:
            text, p, std, agree = "No acute cardiopulmonary abnormality is identified.", \
                1 - max(x["prob"] for x in findings), float(np.mean([x["std"] for x in findings])), 1.0
        else:
            text = POS.get(f["key"], f"Findings suggest {f['name'].lower()}.") if present else NEG[f["key"]]
            p, std = (f["prob"] if present else 1 - f["prob"]), f["std"]
            agree = float(np.mean((f["views"] >= POS_THRESH) == present))
        conf = (0.5 + 0.5 * abs(2 * p - 1)) * max(0.0, 1 - 3 * std)
        sents.append({"text": text, "confidence": round(float(np.clip(conf, 0.02, 0.99)), 2),
                      "supported": bool(agree >= 0.75 and conf >= 0.55),
                      "agreement": round(agree, 2)})
    scores = [x["confidence"] for x in sents]
    return sents, round(0.6 * float(np.mean(scores)) + 0.4 * min(scores), 2)

# ---------------------------------------------------------------- verification + confidence (simulated fallback)
def verify_and_score(sentences, quality, rng):
    """>>> REPLACE LATER <<<  real consistency check (semantic entropy) and
    uncertainty estimation (MC-Dropout + autoencoder) go here.
    Simulated: per-sentence score = image quality blended with noise;
    invented findings get a low score."""
    out = []
    for s in sentences:
        invented = s in HALLUCINATIONS
        if invented:
            c = rng.uniform(0.25, 0.50)
        else:
            c = 0.55 + 0.4 * quality + rng.uniform(-0.08, 0.08)
        c = float(np.clip(c, 0.05, 0.99))
        out.append({"text": s, "confidence": round(c, 2),
                    "supported": (not invented) and c >= 0.6})
    scores = [x["confidence"] for x in out]
    report_score = round(0.6 * float(np.mean(scores)) + 0.4 * min(scores), 2)
    return out, report_score


def status_for(score, threshold):
    return "Verified" if score >= threshold else "Review Required"  # FR-4.2, FR-5.2


# ---------------------------------------------------------------- routes
@app.route("/")
def index():
    return render_template("index.html", default_threshold=DEFAULT_THRESHOLD, engine=ENGINE)


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="File is larger than 10 MB. Upload a smaller JPEG or PNG."), 413


@app.route("/api/analyze", methods=["POST"])
def analyze():
    f = request.files.get("xray")
    if not f or not f.filename:
        return jsonify(error="No file selected. Choose a chest X-ray image."), 400
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED:
        return jsonify(error="Unsupported format. Upload a JPEG or PNG image."), 400
    raw = f.read()
    col = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
    if col is None:
        return jsonify(error="This file could not be read as an image. Try another file."), 400
    b, g, r = [c.astype(int) for c in cv2.split(col)]
    if (abs(b - g) + abs(g - r)).mean() > 12:
        return jsonify(error="This looks like a colour photo, not a chest X-ray. Upload a greyscale chest radiograph."), 400
    img = cv2.cvtColor(col, cv2.COLOR_BGR2GRAY)

    threshold = float(request.form.get("threshold", DEFAULT_THRESHOLD))
    rng = random.Random(int(hashlib.sha256(raw).hexdigest(), 16))  # same image -> same result
    steps = []

    t = time.time()
    processed, metrics = preprocess(img)
    steps.append({"name": "Preprocessing", "ms": int((time.time() - t) * 1000), "real": True})

    findings_out = []
    if ENGINE == "model":
        t = time.time()
        findings = predict_findings(img)       # model sees the ORIGINAL image (not CLAHE)
        steps.append({"name": "Finding detection (CNN)", "ms": int((time.time() - t) * 1000), "real": True})
        t = time.time()
        scored, report_score = report_from_findings(findings)
        steps.append({"name": "Report, verification and scoring", "ms": int((time.time() - t) * 1000), "real": True})
        findings_out = sorted([{"name": f["name"], "prob": round(f["prob"], 3), "std": round(f["std"], 3),
                                "positive": f["prob"] >= POS_THRESH} for f in findings], key=lambda x: -x["prob"])
        method, model_name = "agreement across augmented views (test-time augmentation)", "TorchXRayVision DenseNet-121 (all)"
    else:
        t = time.time()
        label, sentences = generate_report(f.filename, rng, request.form.get("case", "auto"))
        steps.append({"name": "Report generation", "ms": int((time.time() - t) * 1000), "real": False})
        t = time.time()
        scored, report_score = verify_and_score(sentences, metrics["quality"], rng)
        steps.append({"name": "Verification and confidence scoring", "ms": int((time.time() - t) * 1000), "real": False})
        method, model_name = "simulated stub", f"{MODEL_NAME} {MODEL_VERSION}"

    original = cv2.resize(img, (512, 512), interpolation=cv2.INTER_AREA)
    return jsonify(
        original=to_data_url(original), processed=to_data_url(processed),
        metrics=metrics, sentences=scored, score=report_score,
        threshold=threshold, status=status_for(report_score, threshold),
        model=model_name, method=method, engine=ENGINE, findings=findings_out, steps=steps,
    )


if __name__ == "__main__":
    app.run(debug=True)

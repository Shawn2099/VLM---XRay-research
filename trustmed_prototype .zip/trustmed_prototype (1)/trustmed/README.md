# TrustMed prototype (Review 1)

    pip install -r requirements.txt
    python app.py          # open http://127.0.0.1:5000

Tip: name test files with a hint (pneumonia_01.jpg, normal_02.png, covid_03.png, tb_04.png) to choose the report type.
Same image always gives the same result (seeded by file contents).

Real: upload/validation, preprocessing, display, threshold flagging.
Simulated: report generation + verification/confidence (search for ">>> REPLACE LATER <<<" in app.py).
